import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
        backgroundColor: Colors.blue,
    ),
    body: SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(height: 50),

          SizedBox(
            height: 110,
            width: 400,

            child: TextField(
              decoration: InputDecoration(
                suffixIcon: Icon(Icons.search),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                hintText: "Recherchez un article.....",

              ),
            ),

          ),
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                    width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    color: Colors.blue
                  ),


                ),
            Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
                color: Colors.red
            ))
              ],
            ),
          ),
        ],
      )
    )
    );
  }
}
