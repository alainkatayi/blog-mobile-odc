import 'package:app/business/models/Authentification.dart';
import 'package:app/business/models/user.dart';

abstract class BlogNetworkService {
  Future<User> authentifier(Authentification data);
}