import 'package:app/business/models/article.dart';
import 'package:flutter/material.dart';


class CarteArticles extends StatelessWidget {
  //final String? title;
  //final String? auteur;
  //final String? photo;
  //final String? dateCreation;
  //final int? nbrComment;
  Article? article;

  CarteArticles(String? title, String? auteur, String? photo, DateTime? datecreation, {
    this.article,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(20),
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color:Colors.red),
        borderRadius:  BorderRadius.circular(15)
      ),
      child: Padding(
        padding: EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // En-tête avec image et titre
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [

                Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      Text(
                        "Auteur: Nom de l'auteur ${article?.auteur ?? ""}",
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 20,
                        ),
                      ),
                      Text(
                        "Titre de l'article: ${article?.title ?? ""}",
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 5),

                    ],
                  ),
                ),
                Container(
                  width: 400,  // Largeur du rectangle
                  height: 150, // Hauteur du rectangle
                  decoration: BoxDecoration(
                    color: Colors.red,

                    borderRadius: BorderRadius.circular(15), // Coins arrondis
                    image: DecorationImage(
                      image: AssetImage(article?.photo ?? "assets/images/default.png"),
                      fit: BoxFit.cover, // Ajuste l'image
                    ),
                  ),
                ),


              ],
            ),

            SizedBox(height: 15),

            // Date de création
            Text(
              "Date: ${article?.datecreation ?? 2025-03-31 }",
              style: TextStyle(
                color: Colors.white70,
                fontSize: 12,
              ),
            ),

            SizedBox(height: 15),

            // Section commentaires
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [



                ElevatedButton(
                    onPressed: (){},
                    child: Icon(Icons.thumb_up, color: Colors.red,)
                ),

                ElevatedButton(
                    onPressed: () {
                      // Action pour commenter
                    },
                    style: ElevatedButton.styleFrom(
                      iconColor: Colors.red[700],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    child:
                    Row(
                      children: [
                        Icon(Icons.comment, color: Colors.red,),



                        Text(

                          "${article?.nbrComment ?? 0}",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    )


                ),

                ElevatedButton(
                    onPressed: (){},
                    child: Icon(Icons.share, color: Colors.red,),
                    //child: Icon(Icons.heart_broken, color: Colors.red,)
                ),




              ],
            ),

            SizedBox(height: 10),

            // Bouton "Voir plus"

          ],
        ),
      ),
    );
  }
}