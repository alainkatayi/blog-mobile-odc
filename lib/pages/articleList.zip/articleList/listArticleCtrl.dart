import 'package:app/pages/articleList/listArticleState.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ListArticleCtrl extends StateNotifier <ListArticleState>{
  ListArticleCtrl():super(ListArticleState()){

  }

  get data => null;

  Future <void> recupererArticle() async {}
  Future <void> rechercherArticle( String texte ) async{}
  Future <void>  liker( int articleid) async {}
  Future <void> partager(int articleid) async{}
  Future <void> filtrParCatgeories( int categoriid) async{}
  Future <void> trier(String colonne, String ordre)  async {}
  Future <void> chargerPage() async {}

}


final listArticleCtrlPorvider = StateNotifierProvider<ListArticleCtrl, ListArticleState> ((ref){

  return ListArticleCtrl();
});